﻿using Microsoft.AspNetCore.Mvc;
using StudentApps.Models;

namespace StudentApps.Controllers
{
    public class StudentController : Controller
    {
        // GET
        public IActionResult Index()
        {
            return View();
            
        }
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Create(Student student)
        {
            if (ModelState.IsValid)
            {
                return Content("thank u");
            }
            else
            {
                return View(student);  
            }
            
        }
    }
}