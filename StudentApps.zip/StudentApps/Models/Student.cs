﻿using System.ComponentModel.DataAnnotations;

namespace StudentApps.Models
{
    public class Student
    {
        [Required(ErrorMessage = "please enter your leg number")]
        public int RegNo { get; set; }
        [Required(ErrorMessage = "your name is required")]
        [StringLength(200)]
        public string Name { get; set; }
    }
}